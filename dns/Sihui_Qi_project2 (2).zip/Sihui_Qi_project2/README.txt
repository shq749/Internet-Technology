0. Please write down the full names and netids of both your team members.

Sihui Qi
sq77


1. Briefly discuss how you implemented your recursive client functionality.

I started implementing client functionality by just reading the text file provided line by line, and create two sockets that can be used to bind servers. After this, I added an if function which checks for whether the "NS" flag is in the response of root server or not.If not, append the response to resolved.txt.  
If the flag is in the response of RS, the client will send the query again to the top server and append the responses of TS to the resolved.txt file. 


2. Are there known issues or functions that aren't working currently in your
   attached code? If so, explain.

All my functions are working properly as of now. 


3. What problems did you face developing code for this project?

The first big problem that I encountered is ilab problems. ilab and the duo software have problems recongizing the user logging in, and it always crash when I got a connection. The firefox brwoser also returns the message "not responding" which really affected my efficiency in using drive to test codes and backup files. 
The second big problem that I faced is I had a bit hard time understanding some of the instructions, and I implemented some wrong functions when I was writing rs.py, and I misread. 
The third big problem is python grammar. I haven't learned anything about python (except project1) in the past so I really struggled to understand the basics and functions like listen() and socket when coming to remote hosts. 


4. What did you learn by working on this project?

I learned how to create a connection between remote hosts, as well as how to replaced lines in files(rs.py). I also learned a lot about basics of python. 