import threading
import time
import socket
import sys
def client():
    try:
        s1 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        print("[C]: Client sockets created")
    except socket.error as err:
        print('socket open error: {} \n'.format(err))
        exit()
    bind_rs = (socket.gethostbyname(sys.argv[1]), int(sys.argv[2]))
    s1.connect(bind_rs)
    tscon=False
    with open('PROJI-HNS.txt','r')as f: 
        for line in f:
            data=line.encode('utf-8')
            s1.send(data)
            rsrep=s1.recv(200).decode('utf-8')
            print("[C]: Data received from RS: {}".format(rsrep))
            if rsrep: 
                if "- NS" not in rsrep:
                    with open('RESOLVED.txt','a') as fd:
                        fd.write(rsrep+'\n')
                else:
                    if tscon==False:
                        TS=rsrep.replace(' - NS','')
                        bind_ts=(socket.gethostbyname(TS), int(sys.argv[3]))
                        s2.connect(bind_ts)
                        tscon=True
                    s2.send(data)
                    tsrep=s2.recv(200).decode('utf-8')
                    print("[C]: Data received from TS: {}".format(tsrep))
                    with open('RESOLVED.txt','a') as fd:
                        fd.write(tsrep+'\n')
            else:
                break
    s1.close()
    s2.close()
    exit()
if __name__ == "__main__":
    t = threading.Thread(name='client', target=client)
    t.start()
