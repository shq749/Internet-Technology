import threading
import sys
import socket
import fileinput

def replaceTS(file,prev,now):
    for line in fileinput.input(file, inplace=1):
        line=line.replace(prev,now)
        sys.stdout.write(line)
def rs():
    try:
        s1 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        print("[RS]: RS socket created")
    except socket.error as err:
        print('socket open error: {}\n'.format(err))
        exit()
    bindc=('', int(sys.argv[1]))
    s1.bind(bindc)
    tsname=sys.argv[2]
    s1.listen(1)
    hostNAME = socket.gethostname()
    flag=' - NS'
    tshost=tsname + flag
    print("[RS]: Server host name is {}".format(hostNAME))
    localhost_ip = (socket.gethostbyname(hostNAME))
    print("[RS]: Server IP address is {}".format(localhost_ip))
    clientsock, addr = s1.accept()
    print ("[RS]: Got a connection request from a client at {}".format(addr))
    
    while True: 
        
        file=open('PROJI-DNSRS.txt','r')
        RSDNS=[]
        flaginfile=False
        for line in file:
            line_data=line.strip()
            if flaginfile==False: 
                if flag in line:
                    flaginfile=True
                    #line=line.replace(line_data,tshost)
                    replaced=line.replace(flag, '')
                    replaceTS('PROJI-DNSRS.txt',str(replaced).strip(),tsname)
                    break
            RSDNS.append(line_data)
        
        if flaginfile==False:
            with open ('PROJI-DNSRS.txt','a') as fd:
                fd.write(tshost)
                flaginfile=True
        length=len(RSDNS)
        line_num=0
        received=clientsock.recv(200).decode("utf-8").strip()
        print("[RS]: Client Message: {}".format(received))
        if not received: 
            break
        for i in RSDNS:
            line_num=line_num+1
            if received.casefold() in i.casefold() and received.casefold()[:2] == i.casefold()[:2]:
                back=i.encode('utf-8')
                print("[RS]: Message back: {}".format(back.decode('utf-8').strip()))
                clientsock.send(back)
                line_num=0
            else: 
                if line_num==length:
                    clientsock.send(tshost.encode('utf-8'))
                    print("[RS]: Message back: {}".format(tshost.strip()))
                    break
    print("[RS]: All client messages processed.")    
    clientsock.close()              
    s1.close()
    exit()
    file.close()
if __name__ == "__main__":
    t = threading.Thread(name='rs', target=rs)
    t.start() 
