import threading
import sys
import socket

def ts():
    try:
        s1 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        print("[TS]: TS socket created")
    except socket.error as err:
        print('socket open error: {}\n'.format(err))
        exit()
    bindc=('', int(sys.argv[1]))
    s1.bind(bindc)
    s1.listen(1)
    hostNAME = socket.gethostname()
    print("[TS]: Server host name is {}".format(hostNAME))
    localhost_ip = (socket.gethostbyname(hostNAME))
    print("[TS]: Server IP address is {}".format(localhost_ip))
    clientsock, addr = s1.accept()
    print ("[TS]: Got a connection request from a client at {}".format(addr))
    
    while True: 
        errorM=' - Error:HOST NOT FOUND'
        file=open('PROJI-DNSTS.txt','r')
        TSDNS=[]
        for line in file:
            line_data=line.strip()
            TSDNS.append(line_data)
        length=len(TSDNS)
        line_num=0
        received=clientsock.recv(200).decode("utf-8").strip()
        print("[TS]: Client Message: {}".format(received))
        if not received: 
            break
        for i in TSDNS:
            line_num=line_num+1
            if received.casefold() in i.casefold() and received.casefold()[:2] == i.casefold()[:2]:
                back=i.encode('utf-8')
                clientsock.send(back)
                line_num=0
                print("[TS]: Message back: {}".format(back.decode('utf-8').strip()))
            else: 
                if line_num==length:
                    notfound=received+errorM
                    clientsock.send(notfound.encode('utf-8'))
                    print("[TS]: Message back: {}".format(notfound.strip()))
                    break
    print("[TS]: All client messages processed.")    
    clientsock.close()              
    s1.close()
    exit()
    file.close()
if __name__ == "__main__":
    t = threading.Thread(name='ts', target=ts)
    t.start() 
